package Exe01_v2;

import java.util.Scanner;

public class Exe01_v2 {

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Primeiro número:");
			int x = sc.nextInt();
			
			System.out.println("Segundo número:");
			int y = sc.nextInt();
			
			System.out.printf("Soma: %d ", (x + y));

			sc.close();
	}

}
